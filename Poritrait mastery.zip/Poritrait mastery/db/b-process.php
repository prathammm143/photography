<?php
$con=mysqli_connect('localhost','root','','Poritrait mastery');
if(!$con){
    echo " Error to Connect DB";
}
?>

<?php
    
    if (isset($_POST['submit'])) {
        $name = $_POST['b-name'];
        $email = $_POST['b-email'];
        $message = $_POST['b-message'];
        $sql = "INSERT INTO `blog`(`b_name`, `b_email`, `b_comment`) VALUES ('$name','$email','$message')";
        $result = mysqli_query($con, $sql);
        echo "<script>window.open('../single-blog.html','_self')</script>";
        if ($result) {
            // $msg = 'Admin Register Successfully';
            echo "<script>alert('')</script>";
          
            // header("Location:home.php");
        } else {
            echo "<script>alert('Try Again Later!')</script>";
        }

        // mysqli_close($con);
    }
