<?php
$con=mysqli_connect('localhost','root','','Poritrait mastery');
if(!$con){
    echo " Error to Connect DB";
}
?>

<?php
    
    if (isset($_POST['submit'])) {
        $name = $_POST['msg-name'];
        $email = $_POST['msg-email'];
        $subject = $_POST['msg-subject'];
        $message = $_POST['message'];
        $sql = "INSERT INTO `contact`( `msg-name`, `msg-email`, `msg-subject`, `message`) VALUES ('$name','$email','$subject','$message')";
        $result = mysqli_query($con, $sql);
        echo "<script>window.open('../contact.html','_self')</script>";
        if ($result) {
            // $msg = 'Admin Register Successfully';
            echo "<script>alert('')</script>";
          
            // header("Location:home.php");
        } else {
            echo "<script>alert('Try Again Later!')</script>";
        }

        // mysqli_close($con);
    }
